﻿using DBLibrary.Models;
using DBLibrary.Repo;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Case_Study_RestAPI_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartItemController : ControllerBase
    {
        private readonly ICartItem _int1;
        public CartItemController(ICartItem icontext)
        {
            _int1 = icontext;
        }
        // GET: api/<CartItemController>
        [HttpGet]
        public IEnumerable<CartItem> Get()
        {
            return _int1.GetCartItem();
        }

        // GET api/<CartItemController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<CartItemController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<CartItemController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<CartItemController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
